This example is derived from blinkyl4 and demonstrates usage of the extra 32kB RAM2 under gcc and suite:
- in linker script, RAM2 memory area added and an output section named .ram2 directed to it
- note, that all variables placed in .ram2 are initialized to zero, see FillZeroRam2 in startupxxx.s
- in .c, variables to be placed in .ram have to have __attribute__((section(".ram2")))  added 
  to their definition, see delayN
- when generating .bin (or .hex) using objcopy, .ram2 has to be excluded explicitly 
  using --remove-section (or -R) option

  