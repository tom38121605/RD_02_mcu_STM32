// blinky, this demonstrates using RAM2

// #define NUCLEOL4
#define DISCOL4  // LEDs are: PB2 (red), PE8 (green)

#ifdef NUCLEOL4
  #ifdef DISCOL4
    #error "oh, can't define both"
  #endif
#endif

#ifdef DISCOL4
  #define LPTIM_PWM_RED  // PB2 at AF1 is LPTIM1_OUT
#endif


#include <stdint.h>
#include "stm32l476xx.h"

// -------- stuff missing from the stm32XXXxx.h
  // GPIOx_MODER - 2 bits per pin
#define GPIO_Mode_In                         0x00  // GPIO Input Mode
#define GPIO_Mode_Out                        0x01  // GPIO Output Mode
#define GPIO_Mode_AlternateFunction          0x02  // GPIO Alternate function Mode
#define GPIO_Mode_Analog                     0x03  // GPIO Analog Mode


#define AFRL AFR[0]
#define AFRH AFR[1]
#define GPIO_AFRL_AFRL0_0  ((uint32_t)0x00000001)
#define GPIO_AFRL_AFRL1_0  ((uint32_t)0x00000010)
#define GPIO_AFRL_AFRL2_0  ((uint32_t)0x00000100)
#define GPIO_AFRL_AFRL3_0  ((uint32_t)0x00001000)
#define GPIO_AFRL_AFRL4_0  ((uint32_t)0x00010000)
#define GPIO_AFRL_AFRL5_0  ((uint32_t)0x00100000)
#define GPIO_AFRL_AFRL6_0  ((uint32_t)0x01000000)
#define GPIO_AFRL_AFRL7_0  ((uint32_t)0x10000000)
#define GPIO_AFRH_AFRH8_0  ((uint32_t)0x00000001)
#define GPIO_AFRH_AFRH9_0  ((uint32_t)0x00000010)
#define GPIO_AFRH_AFRH10_0 ((uint32_t)0x00000100)
#define GPIO_AFRH_AFRH11_0 ((uint32_t)0x00001000)
#define GPIO_AFRH_AFRH12_0 ((uint32_t)0x00010000)
#define GPIO_AFRH_AFRH13_0 ((uint32_t)0x00100000)
#define GPIO_AFRH_AFRH14_0 ((uint32_t)0x01000000)
#define GPIO_AFRH_AFRH15_0 ((uint32_t)0x10000000)

#define GPIO_AlternateFunction_SYS       0   /* default */
#define GPIO_AlternateFunction_TIM1_1    1
#define GPIO_AlternateFunction_TIM2_1    1
#define GPIO_AlternateFunction_TIM5_1    1
#define GPIO_AlternateFunction_TIM8_1    1
#define GPIO_AlternateFunction_LPTIM1    1
#define GPIO_AlternateFunction_TIM1_2    2
#define GPIO_AlternateFunction_TIM2_2    2
#define GPIO_AlternateFunction_TIM3      2
#define GPIO_AlternateFunction_TIM4      2
#define GPIO_AlternateFunction_TIM5_2    2
#define GPIO_AlternateFunction_TIM8_3    3
// [etc]
#define GPIO_AlternateFunction_EVENTOUT  15


// --------  trivial loopdelay

volatile uint32_t __attribute__((section(".ram2"))) delayN;

void LoopDelay(uint32_t n) {
  delayN = n;
  while(delayN > 0) delayN--;
}

#define DELAY_CONSTANT 50000


// --------  main

#if defined(NUCLEOL4)
int main(void) {
  RCC->AHB2ENR |= 0
    | RCC_AHB2ENR_GPIOAEN
  ; 
  GPIOA->MODER = (GPIOA->MODER 
    & (~GPIO_MODER_MODER5)      // GREEN LED
  ) | (0 
    | (GPIO_Mode_Out * GPIO_MODER_MODER5_0)   // GREEN LED
  );

  while(1) {
    GPIOA->BSRR = 0
      | GPIO_BSRR_BS_5          // GREEN LED - set
    ;
    LoopDelay(DELAY_CONSTANT);
    GPIOA->BSRR = 0
      | GPIO_BSRR_BR_5          // GREEN LED - reset
    ;
    LoopDelay(DELAY_CONSTANT);
  }
}
#else  // if defined(DISCOL4)
int main(void) {
  RCC->AHB2ENR |= 0
    | RCC_AHB2ENR_GPIOBEN
    | RCC_AHB2ENR_GPIOEEN
  ; 
  GPIOB->MODER = (GPIOB->MODER 
    & (~GPIO_MODER_MODER2)      // RED LED
  ) | (0 
  #ifdef LPTIM_PWM_RED
    | (GPIO_Mode_AlternateFunction * GPIO_MODER_MODER2_0)   // RED LED
  #else // conventional GPIO Out
    | (GPIO_Mode_Out * GPIO_MODER_MODER2_0)   // RED LED
  #endif
  );
  GPIOE->MODER = (GPIOE->MODER 
    & (~GPIO_MODER_MODER8)      // GREEN LED
  ) | (0 
    | (GPIO_Mode_Out * GPIO_MODER_MODER8_0)   // GREEN LED
  );

  #ifdef LPTIM_PWM_RED
  GPIOB->AFRL = (GPIOB->AFRL
    & (~GPIO_AFRL_AFRL2)      // RED LED
  ) | (0 
    | (GPIO_AlternateFunction_LPTIM1 * GPIO_AFRL_AFRL2_0)   // RED LED
  );

  RCC->APB1ENR1 |= 0
    | RCC_APB1ENR1_LPTIM1EN
  ;
  LPTIM1->CR = 0 
    | LPTIM_CR_ENABLE
  ;
  LPTIM1->CFGR = 0
    | LPTIM_CFGR_WAVPOL   /*!< Waveform shape polarity */
  ;
  LPTIM1->CR = 0 
    | LPTIM_CR_ENABLE
    | LPTIM_CR_CNTSTRT  // must be started only when _CR.ENABLE = 1
  ;
  LPTIM1->ARR = 0xFFFF; // must be changed only when _CR.ENABLE = 1
  #endif




  while(1) {
  #ifdef LPTIM_PWM_RED
    {
      uint32_t k;
      for (k = 0; k < 0xFFFF; k += 0x0200) {
        LPTIM1->CMP = k;
        LoopDelay(3000);
      }
      LPTIM1->CMP = 0;
    }
  #else
    GPIOB->BSRR = 0
      | GPIO_BSRR_BS_2          // RED LED - set
    ;
    LoopDelay(DELAY_CONSTANT);
    GPIOB->BSRR = 0
      | GPIO_BSRR_BR_2          // RED LED - reset
    ;
    LoopDelay(DELAY_CONSTANT);
  #endif

    GPIOE->BSRR = 0
      | GPIO_BSRR_BS_8          // GREEN LED - set
    ;
    LoopDelay(DELAY_CONSTANT);
    GPIOE->BSRR = 0
      | GPIO_BSRR_BR_8          // GREEN LED - reset
    ;
    LoopDelay(DELAY_CONSTANT);

  }
}
#endif
